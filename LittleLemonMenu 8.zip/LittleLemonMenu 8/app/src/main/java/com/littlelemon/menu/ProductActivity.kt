package com.littlelemon.menu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import com.littlelemon.menu.ui.theme.LittleLemonMenuTheme




class ProductActivity : ComponentActivity() {

    // Companion object com as chaves constantes para os dados do produto
    companion object {
        const val KEY_TITLE = "title"
        const val KEY_PRICE = "price"
        const val KEY_IMAGE = "image"
        const val KEY_CATEGORY = "category"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val productName = intent.getStringExtra(KEY_TITLE)
        val productPrice = intent.getDoubleExtra(KEY_PRICE, 0.0)
        val productCategory = intent.getStringExtra(KEY_CATEGORY)
        val productImage = intent.getIntExtra(KEY_IMAGE, 0)


        val productItem = ProductItem(
            title = productPrice, price = productPrice,
            category = productCategory, image = productImage)

                    setContent {
                 LittleLemonMenuTheme {
                    Surface(color = MaterialTheme.colors.background) {
                    ProductDetails(
                        name = KEY_TITLE, price = productPrice,
                        category = productCategory,
                        imageResource = productImage,
                        productItem = TODO()
                    )
                }
            }
    }
}
}