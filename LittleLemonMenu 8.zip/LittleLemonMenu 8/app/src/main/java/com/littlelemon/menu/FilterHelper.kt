package com.littlelemon.menu

import org.junit.Before
import org.junit.Test


private val Any.title: Any
    get() = Unit

class FilterHelper {

    private lateinit var filterHelper: FilterHelper

    // Sample list of products
    private val sampleProductsList = mutableListOf(
        ProductItem(title = "Black tea", price = 3.00, category = "Drinks", R.drawable.black_tea),
        ProductItem(title = "Croissant", price = 7.00, category = "Dessert", R.drawable.croissant),
        ProductItem(title = "Bouillabaisse", price = 20.00, category = "Food", R.drawable.bouillabaisse)
    )

    @Before
    fun setUp() {
        filterHelper = FilterHelper()
    }

   @Test
   fun filterProducts_filterTypeDessert_croissantReturned(): Unit {

        val result = filterHelper.filterProduct(FilterType.Dessert, sampleProductsList)

       assertEquals(1, result.javaClass)
       assertTrue(result.any { it.title == "Croissant" })
       assertFalse(result.any { it.title == "Black tea" })
       assertFalse(result.any { it.title == "Bouillabaisse" })

       }

    private fun filterProduct(dessert: FilterType.Dessert,
                              sampleProductsList: MutableList<ProductItem>) {

    }

    private fun assertFalse(any: Any) {

    }

    private fun assertTrue(any: Any) {

    }
    private fun assertEquals(any: Any, size: Any) {

    }
}

private fun Unit.any(function: () -> Boolean) {

}

fun filterProducts(type: FilterType, productsList: List<ProductItem>): List<ProductItem> {
        return when (type) {
            FilterType.All -> productsList // Sem filtro, retorna todos os produtos
            FilterType.Dessert -> productsList.filter { it.category == "Dessert" } // Filtro para sobremesas
            FilterType.Drinks -> productsList.filter { it.category == "Drinks" } // Filtro para bebidas
            FilterType.Food -> productsList.filter { it.category == "Food" } // Filtro para comida
        }
    }
