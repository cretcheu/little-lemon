package com.littlelemon.menu.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.littlelemon.menu.ProductActivity
import com.littlelemon.menu.R
import com.littlelemon.menu.ProductItem


class startProductActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_start_product)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
        val selectedProduct = ProductItem("Latte", 8.00, "Drinks", R.drawable.latte) // Exemplo de produto

        // Criando a Intent para iniciar a ProductActivity
        val intent = Intent(this, ProductActivity::class.java)

        // Passando os detalhes do produto selecionado para a ProductActivity
        intent.putExtra(ProductActivity.KEY_TITLE, selectedProduct.title)
        intent.putExtra(ProductActivity.KEY_PRICE, selectedProduct.price)
        intent.putExtra(ProductActivity.KEY_CATEGORY, selectedProduct.category)
        intent.putExtra(ProductActivity.KEY_IMAGE, selectedProduct.image)

        // Iniciando a ProductActivity
        startActivity(intent)

        }
    }