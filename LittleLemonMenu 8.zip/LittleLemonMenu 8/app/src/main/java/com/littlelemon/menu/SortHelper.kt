package com.littlelemon.menu

class SortHelper {

    fun sortProducts(type: SortType, productsList: List<ProductItem>): List<ProductItem> {
        return when (type) {
            SortType.Alphabetically -> productsList.sortAlphabetically()
            SortType.PriceAsc -> productsList.sortPriceAscending()
            SortType.PriceDesc -> productsList.sortPriceDescending()
        }
    }

    // Função de Extensão para Ordenação Alfabética
    private fun List<ProductItem>.sortAlphabetically(): List<ProductItem> {
        return sortedBy { it.title }
    }

    // Função de Extensão para Ordenação por Preço Crescente
    private fun List<ProductItem>.sortPriceAscending(): List<ProductItem> {
        return sortedBy { it.price }
    }

    // Função de Extensão para Ordenação por Preço Decrescente
    private fun List<ProductItem>.sortPriceDescending(): List<ProductItem> {
        return sortedByDescending { it.price }
    }
}