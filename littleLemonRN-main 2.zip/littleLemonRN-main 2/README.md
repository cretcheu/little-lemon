## Little Lemon

This is the code example for the newsletter subscription application.

![](little_lemon.gif)
