package com.litecodez.littlelemon

val baseApi = "https://oshane-mckenzie.github.io/misc"

object Screens {
    const val Splash = "splash"
    const val Login = "login"
    const val Home = "home"
    const val Profile0 = "profile0"
    const val Profile1 = "profile1"
    const val Profile2 = "profile2"
    const val Profile = "profile"

}
const val aboutLittleLemonRestaurant = "The Little Lemon restaurant is a family-owned Mediterranean restaurant offering authentic, flavorful dishes made from fresh ingredients, served in a warm, inviting, and culturally rich atmosphere."