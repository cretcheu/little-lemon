package com.litecodez.littlelemon.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@Composable
fun LTopAppBar(modifier: Modifier = Modifier, backgroundColor: Color = Color.Black, content:@Composable () -> Unit = {}){
    Row(modifier = modifier.background(backgroundColor)) {
        content()
    }
}