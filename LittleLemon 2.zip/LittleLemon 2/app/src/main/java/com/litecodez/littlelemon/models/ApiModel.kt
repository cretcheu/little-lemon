package com.litecodez.littlelemon.models

import com.litecodez.littlelemon.baseApi


data class ApiModel(
    var base:String = baseApi,
    var endPoint:String = "",
    var params:List<String> = listOf()
)