package com.litecodez.littlelemon.objects

enum class AnimationStyle {
    RIGHT, LEFT, SCALE_IN_TOP, SCALE_IN_LEFT, UP, DOWN, TRANSITION, SCALE_IN_CENTER, NONE
}