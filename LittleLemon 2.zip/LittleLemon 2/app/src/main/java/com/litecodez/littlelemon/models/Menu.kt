package com.litecodez.littlelemon.models

import com.google.gson.annotations.SerializedName

data class Menu(
    @SerializedName("menu") @JvmField var menuItems: List<MenuItem> = listOf(MenuItem())
)
