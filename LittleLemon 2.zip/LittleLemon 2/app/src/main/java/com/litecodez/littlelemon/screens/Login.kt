package com.litecodez.littlelemon.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.litecodez.littlelemon.R
import com.litecodez.littlelemon.Screens
import com.litecodez.littlelemon.appNavigator
import com.litecodez.littlelemon.llDataStore
import com.litecodez.littlelemon.savePreferences

//0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377
@Composable
fun Login(modifier: Modifier = Modifier){
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    Box(modifier = modifier){
        Column(
            modifier = Modifier
                .matchParentSize()
                .background(color = Color.White)
                .verticalScroll(scrollState)
                .padding(8.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(144.dp))
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "logo",
                modifier = Modifier

                    .clip(CircleShape)
                    .size(233.dp)
            )
            Spacer(modifier = Modifier.height(34.dp))
            Text(text = "Welcome back!",
                color = Color.Black, fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,

                )
            Spacer(modifier = Modifier.height(34.dp))
            Button(
                onClick = {

                    appNavigator.setViewState(Screens.Splash)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Yellow, contentColor = Color.Black)
            ) {
                Text(text = "Login", fontSize = 21.sp)
            }
        }

    }
}