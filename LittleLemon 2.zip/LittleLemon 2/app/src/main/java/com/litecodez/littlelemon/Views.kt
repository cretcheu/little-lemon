package com.litecodez.littlelemon

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import com.litecodez.littlelemon.components.SimpleAnimator
import com.litecodez.littlelemon.objects.AnimationStyle
import com.litecodez.littlelemon.screens.Home
import com.litecodez.littlelemon.screens.Login
import com.litecodez.littlelemon.screens.Profile
import com.litecodez.littlelemon.screens.Profile0
import com.litecodez.littlelemon.screens.Profile1
import com.litecodez.littlelemon.screens.Profile2
import com.litecodez.littlelemon.screens.Splash


@SuppressLint("SourceLockedOrientationActivity")
@Composable
fun Views(modifier: Modifier = Modifier){
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val activity = context as Activity
    val scope = rememberCoroutineScope()
    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

    Box(modifier = modifier){
        appNavigator.GetBackHandler(context = context, lifecycleOwner = lifecycleOwner)

        when(appNavigator.getView()){
            Screens.Splash -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.RIGHT, isVisible = true) {
                    Splash(modifier = Modifier.fillMaxSize())
                }
            }


            Screens.Profile0 -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.RIGHT, isVisible = true) {
                    Profile0(modifier = Modifier.fillMaxSize())
                }
            }
            Screens.Profile1 -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.SCALE_IN_CENTER, isVisible = true) {
                    Profile1(modifier = Modifier.fillMaxSize())
                }
            }
            Screens.Profile2 -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.SCALE_IN_CENTER, isVisible = true) {
                    Profile2(modifier = Modifier.fillMaxSize())
                }
            }
            Screens.Profile -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.RIGHT, isVisible = true) {
                    Profile(modifier = Modifier.fillMaxSize())
                }
            }
            Screens.Home -> {
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.RIGHT, isVisible = true) {
                    Home(modifier = Modifier.fillMaxSize())
                }
            }
            Screens.Login->{
                SimpleAnimator(modifier = Modifier.fillMaxSize(), style = AnimationStyle.RIGHT, isVisible = true) {
                    Login(modifier = Modifier.fillMaxSize())
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {

        }
    }
}