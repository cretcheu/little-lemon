package com.litecodez.littlelemon.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.litecodez.littlelemon.R
import com.litecodez.littlelemon.Screens
import com.litecodez.littlelemon.appNavigator
import com.litecodez.littlelemon.baseApi
import com.litecodez.littlelemon.dataRepo
import com.litecodez.littlelemon.llDataStore
import com.litecodez.littlelemon.loadPreferences
import com.litecodez.littlelemon.models.ApiModel
import com.litecodez.littlelemon.savePreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun Splash(modifier: Modifier = Modifier){
    val infiniteTransition = rememberInfiniteTransition(label = "")
    val context = LocalContext.current

    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ), label = ""
    )

    Box(modifier = modifier.background(color = Color.White)){
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "logo",
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .clip(CircleShape)
                .size(200.dp)
        )
    }

    LaunchedEffect(Unit) {
        dataRepo.scope.launch {
            delay(2000)
            dataRepo.fetchApiData(apiModel = ApiModel(base = baseApi, endPoint = "/menu.json")){ data ->
                dataRepo.createMenu(data){
                    llDataStore.menu.value = it
                    try{

                        var isLoggedIn = false
                        if(
                            loadPreferences(context,"firstLogin", "true").toBoolean() ||
                            loadPreferences(context,"firstName", "").isNotEmpty() ||
                            loadPreferences(context,"lastName", "").isNotEmpty()
                        ){
                            isLoggedIn = true
                        }
                        if(isLoggedIn){

                            appNavigator.setViewState(Screens.Home)
                        }else{
                            savePreferences(context = context, key = "firstLogin", value = "true")
                            appNavigator.setViewState(Screens.Profile0)
                        }

                    }catch (e:Exception){
                        savePreferences(context = context, key = "firstLogin", value = "true")
                        appNavigator.setViewState(Screens.Profile0)
                    }
                }
            }
        }
    }
}