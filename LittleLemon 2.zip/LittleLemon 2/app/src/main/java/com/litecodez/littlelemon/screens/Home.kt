package com.litecodez.littlelemon.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.litecodez.littlelemon.R
import com.litecodez.littlelemon.Screens
import com.litecodez.littlelemon.aboutLittleLemonRestaurant
import com.litecodez.littlelemon.appNavigator
import com.litecodez.littlelemon.components.LTopAppBar
import com.litecodez.littlelemon.components.MenuItemCard
import com.litecodez.littlelemon.llDataStore


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(modifier: Modifier = Modifier) {
    var filterText by rememberSaveable {
        mutableStateOf("")
    }

    Box(modifier = modifier.background(color = Color.White)) {
        Column(
            modifier = Modifier
                .matchParentSize()
                .background(color = Color.White),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LTopAppBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.08f), backgroundColor = Color.Black
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .padding(start = 5.dp, end = 5.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "The Little Lemon", color = Color.White,
                        fontSize = 21.sp, fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = {
                            appNavigator.setViewState(Screens.Profile)
                        },
                        modifier = Modifier.size(55.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "profile", tint = Color.White,
                            modifier = Modifier.size(55.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(3.dp))

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(3.dp),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(id = R.drawable.banner),
                    contentDescription = "banner",
                    modifier = Modifier
                        .clip(RoundedCornerShape(5))
                        .height(120.dp)
                        .fillMaxWidth(),
                    contentScale = ContentScale.FillBounds
                )
                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = aboutLittleLemonRestaurant,
                    color = Color.Black,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.LightGray, shape = RoundedCornerShape(5))
                        .padding(8.dp)
                )

                Spacer(modifier = Modifier.height(5.dp))

                OutlinedTextField(
                    value = filterText,
                    onValueChange = { filterText = it },
                    label = { Text("Search menu...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Gray,
                        unfocusedBorderColor = Color.Gray,
                        cursorColor = Color.Gray,
                        focusedLabelColor = Color.Gray,
                        unfocusedLabelColor = Color.Gray,
                        focusedTextColor = Color.Black
                    )
                )

                Spacer(modifier = Modifier.height(5.dp))

                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    contentPadding = PaddingValues(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalItemSpacing = 8.dp
                ) {
                    val menuItems = llDataStore.menu.value.menuItems.filter {
                        it.name.contains(filterText, ignoreCase = true) ||
                        it.category.contains(filterText, ignoreCase = true) ||
                        it.description.contains(filterText, ignoreCase = true) ||
                        it.price.toString().contains(filterText, ignoreCase = true)
                    }
                    items(menuItems) { item ->
                        MenuItemCard(
                            item = item,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 144.dp)
                        )
                    }
                }
            }
        }
    }
}
