package com.litecodez.littlelemon.models

import com.google.gson.annotations.SerializedName

/**
 * {
      "name": "Fattoush",
      "category": "Side Dish",
      "description": "A Lebanese bread salad with crisp vegetables and sumac dressing.",
      "price": 8.5,
      "main_ingredients": ["Pita Chips", "Lettuce", "Tomatoes", "Cucumbers"],
      "dietary_info": ["Vegan"],
      "img": 19
    }
 */
data class MenuItem(
    @SerializedName("name") @JvmField var name: String = "Fattoush",
    @SerializedName("category") @JvmField var category: String = "Side Dish",
    @SerializedName("description") @JvmField var description: String = "A Lebanese bread salad with crisp vegetables and sumac dressing.",
    @SerializedName("price") @JvmField var price: Double = 8.5,
    @SerializedName("main_ingredients") @JvmField var mainIngredients: List<String> = listOf("Pita Chips", "Lettuce", "Tomatoes", "Cucumbers"),
    @SerializedName("dietary_info") @JvmField var dietaryInfo: List<String> = listOf("Vegan"),
    @SerializedName("img") @JvmField var img: Int = 19
)
