package com.litecodez.littlelemon.components


import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.litecodez.littlelemon.R
import com.litecodez.littlelemon.llDataStore
import com.litecodez.littlelemon.models.MenuItem

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MenuItemCard(modifier: Modifier = Modifier, item: MenuItem) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 5.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = llDataStore.dishImagesMap[item.img]?:R.drawable.logo),
                contentDescription = "logo",
                modifier = Modifier
                    .clip(RoundedCornerShape(3))
                    .height(144.dp)
                    .fillMaxWidth(),
                contentScale = ContentScale.FillBounds
            )
            Spacer(modifier = Modifier.height(3.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = item.name, color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.75f).basicMarquee())
                Text(text = "$${ item.price }", color = Color.Black, modifier = Modifier.weight(0.25f).basicMarquee())
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = item.category,
                color = Color.Black,
                textAlign = TextAlign.Center,
                fontStyle = FontStyle.Italic
            )
            Text(text = item.description, color = Color.Black, textAlign = TextAlign.Center)
        }
    }
}