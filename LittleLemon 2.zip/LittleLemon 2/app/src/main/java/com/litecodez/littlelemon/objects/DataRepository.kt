package com.litecodez.littlelemon.objects

import android.util.Log
import com.google.gson.Gson
import com.litecodez.littlelemon.models.ApiModel
import com.litecodez.littlelemon.models.Menu
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.kotlinx.serializer.KotlinxSerializer
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext

class DataRepository {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val gson = Gson()
    suspend fun fetchApiData(apiModel: ApiModel, apiCallBack: (String) -> Unit = {}) {

        val client = HttpClient()

        try {

            val api = buildString {
                append(apiModel.base)
                append(apiModel.endPoint)
                apiModel.params.forEach {
                    append(it)
                }
            }

            val apiData = withContext(Dispatchers.IO) {
                client.get(api).bodyAsText()
            }
            withContext(Dispatchers.Main){
                apiCallBack(apiData)
            }

        } catch (e: Exception) {
            val api = buildString {
                append(apiModel.base)
                append(apiModel.endPoint)
                apiModel.params.forEach {
                    append(it)
                }
            }
            withContext(Dispatchers.Main){
                apiCallBack("${e.message} $api")
            }
        } finally {
            client.close()
        }
    }

    fun createMenu(data:String, menuCallBack: (Menu) -> Unit = {}){
        try{
            menuCallBack.invoke(gson.fromJson(data, Menu::class.java))
        } catch (e:Exception){
            Log.e("createMenu", e.message.toString())
            menuCallBack.invoke(Menu())
        }
    }
}