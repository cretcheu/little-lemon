package com.litecodez.littlelemon.objects

import androidx.compose.runtime.mutableStateOf
import com.litecodez.littlelemon.R
import com.litecodez.littlelemon.models.Menu

class LLDataStore {
    val dishImagesMap = mapOf(
        0 to R.drawable.l_0,
        1 to R.drawable.l_1,
        2 to R.drawable.l_2,
        3 to R.drawable.l_3,
        4 to R.drawable.l_4,
        5 to R.drawable.l_5,
        6 to R.drawable.l_6,
        7 to R.drawable.l_7,
        8 to R.drawable.l_8,
        9 to R.drawable.l_9,
        10 to R.drawable.l_10,
        11 to R.drawable.l_11,
        12 to R.drawable.l_12,
        13 to R.drawable.l_13,
        14 to R.drawable.l_14,
        15 to R.drawable.l_15,
        16 to R.drawable.l_16,
        17 to R.drawable.l_17,
        18 to R.drawable.l_18,
        19 to R.drawable.l_19
    )
    val menu = mutableStateOf(Menu())
    val userName = mutableStateOf(Pair<String, String>("",""))
}