package com.litecodez.littlelemon

import android.content.Context
import android.widget.Toast

/**
 * Saves user credentials to SharedPreferences.
 *
 * @param value The value to be saved.
 * @param context The context of the application.
 */
fun savePreferences(key:String = "tos", value:String="", context: Context){
    val sharedPreferences = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE)
    val editor = sharedPreferences.edit()
    editor.putString(key, value)
    editor.apply()
}


/**
 * Loads user credentials from SharedPreferences.
 *
 * @param context The context of the application.
 * @return The loaded user credentials, or an empty string if not found.
 */
fun loadPreferences(context: Context, key:String = "tos", default:String = ""):String{
    val sharedPreferences = context.getSharedPreferences("userInfo", Context.MODE_PRIVATE)
    println(sharedPreferences.getString(key, ""))
    return sharedPreferences.getString(key, "") ?: default
}

fun getToast(context: Context, msg:String, long:Boolean = false){
    // Display a toast message with the specified text and duration
    Toast.makeText(
        context,
        msg,
        if(long){
            Toast.LENGTH_LONG}else{
            Toast.LENGTH_SHORT}
    ).show()
}
fun Any.getToastExt(context: Context, msg:String = "", long:Boolean = false):Any{
    // Display a toast message with the specified text and duration
    Toast.makeText(
        context,
        "$this$msg",
        if(long){
            Toast.LENGTH_LONG}else{
            Toast.LENGTH_SHORT}
    ).show()
    return this
}