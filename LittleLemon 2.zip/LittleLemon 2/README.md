# 🍋 Little Lemon Restaurant App

Welcome to **Little Lemon**, a modern restaurant app designed to offer a seamless browsing experience for customers looking to explore our delicious menu and place orders effortlessly.

---

## 📸 Screenshots

<img src="app/little_lemon.jpeg" width="540" alt=""> <img src="app/little_lemon_2.jpeg" width="540" alt="">

<img src="app/little_lemon_3.jpeg" width="540" alt=""> <img src="app/little_lemon_4.jpeg" width="540" alt="">

---

## ✨ Features

✅ Browse a variety of delicious dishes
✅ Search and filter menu items easily
✅ View detailed descriptions, categories, and prices
✅ Modern UI with a **staggered grid layout**
✅ Optimized for **performance and smooth navigation**

---

## 📲 Installation

Clone the repository and open it in **Android Studio**:

```sh
git clone https://github.com/OShane-McKenzie/LittleLemon.git
cd little-lemon-app
```

Run the project on an **Android emulator or physical device**.

---

## 🛠️ Tech Stack

- **Kotlin** with Jetpack Compose

---

## 📌 How It Works

1. Users can **browse** through menu items in a **staggered grid layout**.
2. The **search bar** allows filtering menu items by **name** or **category**.
3. Each menu item displays **an image, price, category, and description**.

---

## 📜 License

This project is licensed under the **MIT License**.

---

## 💡 Contributing

Feel free to **fork** this repository and contribute to enhance the app! Submit a PR with your improvements. 🚀

---

## 📧 Contact

For any inquiries, reach out to **O'Shane McKenzie** at:
📩 [oshanemckenzie5@gmail.com](mailto:oshanemckenzie5@gmail.com)

